--Datos de insercion
USE SeguimientoEgresado
GO
------------------------------------------------
------------------------------------------------
------------------------------------------------
INSERT INTO InfoEgresado (NControl, Nombre, ApellidoPat, ApellidoMat, FechaNacimiento, NoCel, CorreoPer, CorreoInst, Carrera, Periodo, Direccion, Municipio, Estado, OpTitulo, Modalidad, Curp, Laboral)
VALUES
('17038363', 'Juan', 'Perez', 'Floyd', '1999-02-19', '9839839830', 'ivangongora1092@gmail.com', 'L17038363@chetumal.tecnm.mx', 'Ing. Sist. Computacionales', 'Agosto 2017', 'Tepich', 'Bacalar', 'Quintana Roo', 'Titulaci�n Integral', 'Escolariza', 'QASWED130694HRYDFN', 'Si'),
('18983123', 'Carlos', 'Perez', 'Tepich', '2000-06-20', '9836969040', 'francisco.rosales.uwu@gmail.com', 'L18983123@chetumal.tecnm.mx', 'Ing. El�ctrica', 'Agosto 2018', 'Rio verde', 'Othon P. Blanco', 'Quintana Roo', 'Titulaci�n Integral', 'A distanci', 'AZSXDC123234QAWSED', 'No'),
('19012030', 'Tacho', 'Ni�o', 'Cruz', '2002-01-01', '9830180010', 'robertoadriandzulvazquez@gmail.com', 'L19012030@chetumal.tecnm.mx', 'Lic. Turismo', 'Agosto 2019', 'Magisterial', 'Calderitas', 'Quintana Roo', 'No tengo titulo', 'Abierta', 'NI�OGE983NIOPLOKUH', 'Si');
------------------------------------------------
------------------------------------------------
------------------------------------------------
-- Insertar valores en la tabla Empresa
INSERT INTO Empresa (RFCEmpresa, NombreEmpresa, DescripcionEmpresa, LogoEmpresa, EsloganEmpresa, SucursalPrinEmpresa, VacantesTrabajo, TelefonoEmpresa, CorreoEmpresa) 
VALUES 
('EM-1', 'Empresa A', 'Empresa de construcci�n l�der en el mercado.', NULL, NULL, 'Av. Constructor #100, Ciudad de M�xico', 10, '5551112222', 'info@empresaA.com'),
('EM-2', 'Empresa B', 'Empresa dedicada a la importaci�n y exportaci�n de productos.', NULL, NULL, 'Calle Comercial #50, Monterrey', 8, '5552223333', 'contacto@empresaB.com'),
('EM-3', 'Empresa C', 'Despacho legal con amplia experiencia en diferentes ramas del derecho.', NULL, NULL, 'Paseo de los Abogados #200, Guadalajara', 5, '5553334444', 'info@empresaC.com');
------------------------------------------------
------------------------------------------------
------------------------------------------------
-- Insertar valores en la tabla Empleador
INSERT INTO Empleador (IDEmpleador, NombreEmpl, Apellido1Empl, Apellido2Empl, TelefonoEmpl, CorreoEmpl, RFCEmpresa) 
VALUES 
('EP-1', 'Carlos', 'Garc�a', 'Mart�nez', '5551234567', 'garcia@gmail.com', 'EM-2'),
('EP-2', 'Mar�a', 'L�pez', 'Hern�ndez', '5559876543', 'lopez@hotmail.com', 'EM-3');

-- Insertar valores en la tabla JefeDepto
INSERT INTO JefeDepto (IDJefeDepto, NombreJefeDepto, Apellido1JefeDepto, Apellido2JefeDepto, FechaNacimientoJefeDepto, HorarioTrabJefeDepto, Carrera) 
VALUES 
('J-1', 'Juan', 'Perez', 'Maldonado', '1978-03-19', '12:00 PM - 6:00 PM', 'Ing. Sist. Computacionales'),
('J-2', 'Jaquin', 'Guzman', 'Loera', '1960-01-15', '12:00 PM - 6:00 PM', 'Contabilidad'),
('J-3', 'Pablo', 'Ek', 'Huerta', '1960-01-15', '12:00 PM - 6:00 PM', 'Arquitectura');
------------------------------------------------
------------------------------------------------
------------------------------------------------
-- Insertar valores en la tabla GestionVinculacion
INSERT INTO GestionVinculacion (IDGestionVinculacion, NombreGestionVinculacion, Apellido1GestionVinculacion, Apellido2GestionVinculacion, FechaNacimientoGestionVinculacion, HorarioGestionVinculacion) 
VALUES 
('G-1', 'Nombre1', 'Apellido11', 'Apellido12', '1990-01-01', '9:00 AM - 5:00 PM'),
('G-2', 'Nombre2', 'Apellido21', 'Apellido22', '1995-02-02', '9:00 AM - 5:00 PM'),
('G-3', 'Nombre3', 'Apellido31', 'Apellido32', '1985-03-03', '9:00 AM - 5:00 PM');
------------------------------------------------
------------------------------------------------
------------------------------------------------
----Insertar valores a la tabla Evento
INSERT INTO Evento (IDEvento, NombreEvent, DescripcionEvent, NumeroContacto, CorreoContacto, HorarioAtencionEvent,FechaInicioEvent, FechaFinalEvent,CarreraEvent)
VALUES 
('EV-1','Concurso','Evento sobre un concurso', '9830001112','contacto1@hotmail.com', '9:00 AM - 12:00 PM', '2024-04-02', '2024-04-10','Licenciatura en administraci�n'),
('EV-2','Torneo','Descripcion sobre el evento', '9831112223','contacto2@hotmail.com', '5:00 PM - 12:00 AM', '2024-06-08', '2024-06-09', 'Arquitectura');
------------------------------------------------
------------------------------------------------
------------------------------------------------
INSERT INTO JefeDeptoXEvento (IDJefeDepto, IDEvento)
VALUES 
('J-1', 'EV-2');
------------------------------------------------
------------------------------------------------
------------------------------------------------
INSERT INTO GestionVincXEvento (IDGestionVinculacion, IDEvento)
VALUES 
('G-1','EV-1');
------------------------------------------------
------------------------------------------------
------------------------------------------------
-- Insertar valores en la tabla Inicios de sesion general
INSERT INTO InicioSesionGeneral (IdSesion, UsuarioSesion, ContrasenaSesion, RolUsuario)
VALUES 
('S-1', '17038363', '1234', 'Egresado'),
('S-2', '18983123', '1234', 'Egresado'),
('S-3', '19012030', '1234', 'Egresado'),
('S-4', 'juanperez@chetumal.tecnm.mx', 'Contrase�a4', 'JefeDepartemento'),
('S-5', 'jaquinguzman@chetumal.tecnm.mx', 'Contrase�a5', 'JefeDepartemento'),
('S-6', 'pabloek@chetumal.tecnm.mx', 'Contrase�a6', 'JefeDepartemento'),
('S-7', 'gestionvinc1@chetumal.tecnm.mx', 'Contrase�a7', 'GestionVinculacion'),
('S-8', 'gestionvinc2@chetumal.tecnm.mx', 'Contrase�a8', 'GestionVinculacion'),
('S-9', 'gestionvinc3@chetumal.tecnm.mx', 'Contrase�a9', 'GestionVinculacion'),
('S-10', 'garcia@gmail.com', 'Contrase�a10', 'Empleador'),
('S-11', 'lopez@hotmail.com', 'Contrase�a11', 'Empleador');
------------------------------------------------
------------------------------------------------
------------------------------------------------
-- Insertar valores en la tabla InicioSesionEgre
INSERT INTO SesionXEgresado (IdSesion, NControl, Registrado) 
VALUES 
('S-1', '17038363', '1'),
('S-2', '18983123', '1'),
('S-3', '19012030', '0');

-- Insertar valores en la tabla InicioSesionJefeDept
INSERT INTO SesionXJefeDept (IdSesion, IDJefeDepto) 
VALUES 
('S-4', 'J-1'),
('S-5', 'J-2'),
('S-6', 'J-3');
-- Insertar valores en la tabla InicioSesionGestVinc
INSERT INTO SesionXGestVinc (IdSesion, IDGestionVinculacion) 
VALUES 
('S-7', 'G-1'),
('S-8', 'G-2'),
('S-9', 'G-3');

-- Insertar valores en la tabla InicioSesionEmpl
INSERT INTO SesionXEmpleador (IdSesion, IDEmpleador) 
VALUES 
('S-10', 'EP-1'),
('S-11', 'EP-2');